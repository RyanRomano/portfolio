import styled from 'styled-components';

export const Container = styled.div`
	padding-top: 30px;
	padding-left: 10%;
	padding-right: 10%;
`;